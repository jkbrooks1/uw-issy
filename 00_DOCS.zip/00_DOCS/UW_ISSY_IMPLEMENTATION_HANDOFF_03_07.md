# IMPLEMENTATION HANDOFF PROMPT: UW-Issaquah Connectors 03-07 Production Build

Copy this entire document as the prompt for the next coding agent. It is self-contained —
all research is already complete; do not ask the project owner to re-research or manually
fill in anything below. If a genuine gap is found during implementation that this
document doesn't cover, treat it the same way the research cycle did: document it
honestly rather than inventing a source or a result.

---

## OBJECTIVE

Build the production n8n connector workflows for workstreams `03_AIR_QUALITY`,
`04_WILDFIRE`, `05_FLOOD_CONDITIONS`, `06_TRAIL_INFRASTRUCTURE_STATUS`, and
`07_GOVERNMENT_SAFETY_ALERTS` of the UW-Issaquah Route Monitor project, using the
already-completed research in `00_CONNECTORS/0X_*/` and the cross-cutting synthesis in
`00_DOCS/UW_ISSY_*_03_07.*` as your source of truth. Do not re-research sources already
classified MVP/SECONDARY/REJECT/UNRESOLVED below — implement against them directly.

## PROJECT LOCATIONS

- Project root: `/Users/jkbrookspersonal/LocalSiteBuildFiles/BTF_UW-Issy_Route_Monitor`
- Canonical GPX (read-only): `data/route/UnivWA-Issaquah.gpx`
- Per-workstream research (read, do not re-derive): `00_CONNECTORS/03_AIR_QUALITY/`,
  `00_CONNECTORS/04_WILDFIRE/`, `00_CONNECTORS/05_FLOOD_CONDITIONS/`,
  `00_CONNECTORS/06_TRAIL_INFRASTRUCTURE_STATUS/`,
  `00_CONNECTORS/07_GOVERNMENT_SAFETY_ALERTS/`
- Cross-cutting synthesis (read first, this is your build plan):
  `00_DOCS/UW_ISSY_CONNECTOR_RESEARCH_03_07_EXECUTIVE_SUMMARY.md`,
  `00_DOCS/UW_ISSY_CONNECTOR_RESEARCH_03_07_FULL_REPORT.md`,
  `00_DOCS/UW_ISSY_CONNECTOR_REGISTRY_03_07.json`,
  `00_DOCS/UW_ISSY_CONNECTOR_IMPLEMENTATION_MATRIX_03_07.md`,
  `00_DOCS/UW_ISSY_HAZARD_OWNERSHIP_MATRIX_03_07.md`,
  `00_DOCS/UW_ISSY_CONNECTOR_ENV_REQUIREMENTS_03_07.md`,
  `00_DOCS/UW_ISSY_CONNECTOR_SOURCE_TEST_LOG_03_07.md`,
  `00_DOCS/UW_ISSY_NORMALIZED_SCHEMAS_03_07.md`
- Read and follow: `CLAUDE.md`, `AGENTS.md`, `00_PROJECT_RULES.md`,
  `00_PROJECT_STATUS.md`
- Reference (already-built, read-only unless explicitly extending): completed producer
  pattern in `00_CONNECTORS/01_ROUTE_CONDITIONS/` and `00_CONNECTORS/02_WEATHER/`
- Build log (append only, never rewrite): `00_PROJECT_BUILDLOG.md`

## BEFORE WRITING ANY WORKFLOW: FIX THREE CROSS-CUTTING GAPS

These were found during research synthesis and must be resolved architecturally before
any of the five connectors is built, not patched in afterward:

1. **Namespace every source ID by workstream** (e.g. `05:ISS-01`, `06:ISS-01`) in every
   internal identifier, log line, and health-check output. The research registries reuse
   short IDs like `KC-01` and `ISS-01` across different workstreams for different real
   sources — merging them without a namespace prefix will silently corrupt any shared
   dashboard, health page, or dedup logic.
2. **Standardize every connector's output schema on snake_case** field names
   (`schema_version`, `workstream_id`, `route_summary`, `route_segment_impacts`, etc.).
   Workstreams 04, 06, and 07's schema proposals already used this convention; 03 and 05's
   proposals used camelCase and need a field-name translation pass when you implement
   them — the underlying field semantics in `NORMALIZED_SCHEMA_PROPOSAL.md` for each
   workstream are correct, only the casing needs to change for 03 and 05.
3. **Adopt these two fields project-wide on every `events[]` item**, even though only one
   or two workstreams' proposals included them natively:
   - `cross_listed_to: []` (from 07's proposal) — populate whenever the hazard ownership
     matrix says an event should be intentionally shown under more than one workstream.
   - `basis: []` (from 05's proposal) — list the specific source IDs that back a given
     segment or event classification, for auditability.

## BUILD ORDER

Build in this order (see Executive Summary for the readiness/maintenance-burden
reasoning): **05_FLOOD_CONDITIONS -> 07_GOVERNMENT_SAFETY_ALERTS -> 04_WILDFIRE ->
03_AIR_QUALITY -> 06_TRAIL_INFRASTRUCTURE_STATUS**.

## PER-WORKSTREAM BUILD SPEC

For each workstream, build against exactly the MVP source set, cadence, freshness rule,
and failure/fallback behavior already specified in that workstream's own
`IMPLEMENTATION_RECOMMENDATION.md` and the consolidated
`UW_ISSY_CONNECTOR_IMPLEMENTATION_MATRIX_03_07.md`. Do not add a secondary or
unresolved/blocked source to the first production build — promote them later, one at a
time, per each workstream's own promotion-path notes.

### 05_FLOOD_CONDITIONS (build first)

MVP: `USGS-01`, `USGS-02` (USGS IV JSON, 15-min cadence), `NWPS-01` (NOAA Water
Prediction Service, 15-min status / 60-min stageflow), `NWS-01` (flood/flash-flood CAP
alerts, 10-15 min), `ISS-01` (City of Issaquah flood-phase policy page, daily/on-change).
Route-impact model: confirmed route closure -> observed flooding -> forecast flooding ->
probable route impact -> elevated water -> no known route impact (six states, in that
priority order — never skip straight to "no known route impact" just because gauges are
below threshold if a closure source says otherwise). Do not let a gauge or lake-level
reading alone ever produce anything stronger than `elevated_water` without closure or NWS
corroboration. No credential needed for the MVP set.

### 07_GOVERNMENT_SAFETY_ALERTS (build second)

MVP: `NWS-01` (CAP alerts, 8 route-point query + King County zone + statewide backstop,
5-15 min), `SEA-01` (AlertSeattle WordPress API, 15 min), `UW-01` (UW Alert WordPress API,
15 min). **Hard requirement, confirmed necessary by a live test during research, not
theoretical**: filter out any NWS alert whose event type is an Air Quality Alert — those
belong to 03, not 07. Deduplication: CAP identifier first, then source-native ID, then
cross-source clustering by normalized headline + event type + place tokens + effective
time. Display alternate-transport alerts (`ST-01`, `KCMETRO-01`, secondary-tier) in a
visually separate block, never merged into the main hazard count. No credential needed
for the MVP set (`WSDOT_TRAVELER_API_ACCESS_CODE` and FEMA IPAWS credentials are
secondary/unresolved — see below).

### 04_WILDFIRE (build third)

MVP: `NIFC-01` + `NIFC-02` (WFIGS locations + perimeters, 15 min, **must serialize
requests** — a live `429` was hit during research when both were queried in quick
succession), `NWS-01` (Red Flag/Fire Weather Watch, 15 min, zone match against
`WAZ654`/`WAZ657`), `NOAA-01` (HMS smoke polygons, 60 min, **no stable "current" alias
exists** — build the dated-file discovery logic, do not hardcode a guessed URL),
`KC-01` (King County burn bans, HTML scrape, 6 hr). Thresholds: active fire point ≤5mi
(high priority ≤2mi), perimeter within 10mi buffer (high priority 2mi or route-line
intersection), evacuation zone requires real polygon intersection or named-landmark match
(never infer from fire proximity alone), smoke plume 5mi buffer, fire-related route
closure requires named-segment or ≤0.25mi geometry match (do not infer from perimeter
proximity). No credential needed for the MVP set.

### 03_AIR_QUALITY (build fourth)

MVP: `ECO-01` (WA Ecology hourly monitors, 60 min), `ECO-02` (WA Ecology smoke forecast
polygons, 3-6 hr in smoke season / daily off-season), `PSCAA-02` (burn-ban status page,
HTML scrape, 6-12 hr). **Before treating `ECO-01`/`ECO-02` as production-stable, re-test
TLS behavior from the actual production host** — this research cycle found that default
`curl` failed against Ecology with exit 60 while Python `requests` succeeded from the same
local machine; confirm which behavior the production host actually exhibits before
shipping. Recommended point design: 4 official monitor points (Seattle-NE 127th, Lake
Forest Park-Town Center, Bellevue-SE 12th, Issaquah-Lake Sammamish) or, if a simpler first
version is needed, 3 corridor buckets. Use EPA AQI categories directly
(Good/Moderate/USG/Unhealthy/Very Unhealthy/Hazardous) as the rider-facing severity scale
— do not invent a new category system. No credential needed for the MVP set.

### 06_TRAIL_INFRASTRUCTURE_STATUS (build fifth)

MVP: `KC-01`, `KC-02`, `KC-03` (King County Parks trail pages, HTML diff, 6 hr — **no
stable per-alert ID exists on any of these**, implement whole-page/block diffing against
last-known-good, not per-item change detection), `SAM-02` (City of Sammamish creek-project
update, HTML article parse, 12 hr), `ISS-01` (City of Issaquah construction ArcGIS
service, route-corridor + keyword filter, 6 hr). Public-facing label:
**`WATERWAY_AND_CROSSING_STATUS`** (internal folder identifier
`06_TRAIL_INFRASTRUCTURE_STATUS` stays unchanged — do not rename it). Positive keyword
list for filtering: culvert, drainage, storm drainage, fish passage, salmon habitat,
bridge, crossing, shoreline, creek, spillway, boardwalk, washout. Only auto-publish
`high`/`medium` confidence events (exact geometry or facility/trail-name match); keep
`low`-confidence (municipality-only) matches diagnostic/manual-review-only. No credential
needed for the MVP set.

## CREDENTIALS

Test `WSDOT_TRAVELER_API_ACCESS_CODE` first if pursuing any secondary source — it is
already present in this environment by name, was never tested against a live payload in
any of the three workstreams that reference it (05, 06, 07), and independently unlocks
value in all three. Do not provision `NASA_FIRMS_MAP_KEY`, `AIRNOW_API_KEY`, or any FEMA
IPAWS credential unless the project owner explicitly requests promoting one of those
secondary/unresolved sources — none of them block any MVP build. Full detail:
`00_DOCS/UW_ISSY_CONNECTOR_ENV_REQUIREMENTS_03_07.md`. Never print, log, or commit any
credential value.

## HAZARD DEDUPLICATION — IMPLEMENT AS CODE, NOT AS A REMINDER

`00_DOCS/UW_ISSY_HAZARD_OWNERSHIP_MATRIX_03_07.md` is not just documentation — its
escalation rule must be implemented: for any hazard marked "jointly owned" in that matrix
(fire-caused trail closures, flood-caused trail closures, bridge closures, dam incidents,
waterway infrastructure closures), resolve the closure/incident fact from the
closure-of-record workstream, attach cause classification from the causal workstream, and
publish exactly one normalized event referencing both source IDs — never two separate
cards for the same real-world event.

## STANDARD 9-STEP WORKFLOW-COMPLETION RULE (applies to every connector built here)

Per this project's standing rule, no connector is complete until it has been: (1)
statically validated, (2) imported into n8n, (3) live executed, (4) debugged if needed,
(5) write/readback validated if it writes files, (6) final diagnostics validated, (7)
execution proof captured, (8) documented, (9) logged in `00_PROJECT_BUILDLOG.md`. Do not
claim a connector complete from static validation or workflow-JSON export alone.

## VALIDATION BEFORE COMPLETION

1. Confirm every MVP source per workstream is queried exactly as specified above (correct
   cadence, correct freshness threshold, correct fallback behavior).
2. Confirm source IDs are namespaced by workstream everywhere they could collide.
3. Confirm output schemas use snake_case consistently across all five workstreams.
4. Confirm the joint-hazard merge logic produces one event, not two, for a real test case
   in each of the five jointly-owned hazard types.
5. Confirm no credential value is printed, logged, or committed anywhere.
6. Confirm the WFIGS serialization fix is actually in place (no burst parallel queries).
7. Confirm the NOAA HMS dated-file discovery logic works without a hardcoded "current"
   alias.
8. Append a full build-log entry to `00_PROJECT_BUILDLOG.md` for each workstream as it is
   completed, following this project's existing entry format.
9. Copy any new helper script to `/Users/jkbrookspersonal/00_SCRIPTS` with a timestamped
   filename, per this project's script-archive convention.

## DO NOT

- Do not re-research sources already classified in the registry — implement against the
  existing classification, or explicitly justify and document any deviation.
- Do not merge two workstreams' source IDs without the namespace fix above.
- Do not invent a canal authority or force canal-status data into workstream 06 — the
  route does not follow a French canal system, and this was already explicitly tested and
  rejected.
- Do not rename `06_TRAIL_INFRASTRUCTURE_STATUS`'s internal folder identifier.
- Do not promote any UNRESOLVED or BLOCKED source to production without first closing its
  documented blocker (credential, live-item capture, or browser-capable fetch path).
- Do not skip the production-host TLS re-test for Ecology before relying on it for
  03_AIR_QUALITY.
